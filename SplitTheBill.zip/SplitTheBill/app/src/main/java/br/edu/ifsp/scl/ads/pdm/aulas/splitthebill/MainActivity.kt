import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import br.edu.ifsp.scl.ads.pdm.aulas.splitthebill.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val user1EditText = findViewById<EditText>(R.id.user1EditText)
        val user2EditText = findViewById<EditText>(R.id.user2EditText)
        val user3EditText = findViewById<EditText>(R.id.user3EditText)
        val user4EditText = findViewById<EditText>(R.id.user4EditText)
        val resultTextView = findViewById<TextView>(R.id.resultTextView)
        val calculateButton = findViewById<Button>(R.id.calculateButton)

        calculateButton.setOnClickListener {
            val user1Paid = user1EditText.text.toString().toDoubleOrNull() ?: 0.0
            val user2Paid = user2EditText.text.toString().toDoubleOrNull() ?: 0.0
            val user3Paid = user3EditText.text.toString().toDoubleOrNull() ?: 0.0
            val user4Paid = user4EditText.text.toString().toDoubleOrNull() ?: 0.0

            val totalPaid = user1Paid + user2Paid + user3Paid + user4Paid
            val splitAmount = totalPaid / 4

            val user1Owes = splitAmount - user1Paid
            val user2Owes = splitAmount - user2Paid
            val user3Owes = splitAmount - user3Paid
            val user4Owes = splitAmount - user4Paid

            resultTextView.text = """
                User 1 owes: $$user1Owes
                User 2 owes: $$user2Owes
                User 3 owes: $$user3Owes
                User 4 owes: $$user4Owes
            """.trimIndent()
        }
    }
}